/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package testrandom;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class RandomWheelApp extends JFrame {
    private JTextArea textArea;
    private JButton btnConfirm, btnSpin, btnRandomMultiple, btnMultipleRandomOne;
    private WheelPanel wheelPanel;
    private Timer timer;
    private int angle = 0;
    private int speed = 10;
    private List<String> choices;
    private String finalResult;

    public RandomWheelApp() {
        setTitle("Vòng quay may mắn");
        setSize(800, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Panel nhập dữ liệu
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new BorderLayout());

        textArea = new JTextArea(10, 30);
        inputPanel.add(new JScrollPane(textArea), BorderLayout.CENTER);

        btnConfirm = new JButton("Xác nhận lựa chọn");
        inputPanel.add(btnConfirm, BorderLayout.SOUTH);

        add(inputPanel, BorderLayout.WEST);

        // Panel quay vòng tròn
        wheelPanel = new WheelPanel(new ArrayList<>());
        add(wheelPanel, BorderLayout.CENTER);

        // Panel các nút chức năng
        JPanel buttonPanel = new JPanel();
        btnSpin = new JButton("Quay");
        btnRandomMultiple = new JButton("Lựa chọn nhiều lần một lựa chọn");
        btnMultipleRandomOne = new JButton("Lựa chọn một lần nhiều lựa chọn");

        btnSpin.setEnabled(false);
        btnRandomMultiple.setEnabled(false);
        btnMultipleRandomOne.setEnabled(false);

        buttonPanel.add(btnSpin);
        buttonPanel.add(btnRandomMultiple);
        buttonPanel.add(btnMultipleRandomOne);
        add(buttonPanel, BorderLayout.SOUTH);

        btnConfirm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String[] inputChoices = textArea.getText().split("\\n");
                if (inputChoices.length < 2) {
                    JOptionPane.showMessageDialog(null, "Hãy nhập ít nhất hai lựa chọn.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                } else {
                    choices = new ArrayList<>();
                    for (String choice : inputChoices) {
                        if (!choice.trim().isEmpty()) {
                            choices.add(choice.trim());
                        }
                    }
                    if (choices.size() < 2) {
                        JOptionPane.showMessageDialog(null, "Hãy nhập ít nhất hai lựa chọn.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                    } else {
                        wheelPanel.setChoices(choices);
                        btnSpin.setEnabled(true);
                        btnRandomMultiple.setEnabled(true);
                        btnMultipleRandomOne.setEnabled(true);
                    }
                }
            }
        });

        btnSpin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startSpinning(null);
            }
        });

        btnRandomMultiple.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String input = JOptionPane.showInputDialog("Nhập số lần lựa chọn:");
                try {
                    int m = Integer.parseInt(input);
                    if (m <= 0) {
                        JOptionPane.showMessageDialog(null, "Vui lòng nhập số lớn hơn 0.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    finalResult = "Lựa chọn nhiều lần: " + m;
                    startSpinning(() -> {
                        List<String> results = new ArrayList<>();
                        for (int i = 0; i < m; i++) {
                            results.add(getRandomChoice());
                        }
                        JOptionPane.showMessageDialog(null, "Lựa chọn ngẫu nhiên: " + results, "Kết quả", JOptionPane.INFORMATION_MESSAGE);
                    });
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Vui lòng nhập số hợp lệ.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        btnMultipleRandomOne.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String input = JOptionPane.showInputDialog("Nhập số lượng lựa chọn:");
                try {
                    int n = Integer.parseInt(input);
                    if (n <= 0) {
                        JOptionPane.showMessageDialog(null, "Vui lòng nhập số lớn hơn 0.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    if (n > choices.size()) {
                        JOptionPane.showMessageDialog(null, "Số lượng lớn hơn tổng số lựa chọn.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                    } else {
                        finalResult = "Lựa chọn một lần nhiều lựa chọn: " + n;
                        startSpinning(() -> {
                            List<String> randomChoices = getRandomChoices(n);
                            JOptionPane.showMessageDialog(null, "Lựa chọn ngẫu nhiên: " + randomChoices, "Kết quả", JOptionPane.INFORMATION_MESSAGE);
                        });
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Vui lòng nhập số hợp lệ.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        timer = new Timer(100, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                angle += speed;
                if (speed > 0) {
                    speed--;
                } else {
                    timer.stop();
                    if (finalResult == null) {
                        JOptionPane.showMessageDialog(null, "Lựa chọn: " + getSelectedChoice());
                    } else {
                        JOptionPane.showMessageDialog(null, finalResult);
                        finalResult = null;
                    }
                }
                wheelPanel.setAngle(angle);
            }
        });
    }

    private void startSpinning(Runnable onComplete) {
        speed = 20;
        if (onComplete != null) {
            timer.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (speed == 0) {
                        onComplete.run();
                        timer.removeActionListener(this);
                    }
                }
            });
        }
        timer.start();
    }

    private String getRandomChoice() {
        int randomIndex = new Random().nextInt(choices.size());
        return choices.get(randomIndex);
    }

    private String getSelectedChoice() {
        int selectedIndex = (int) ((360 - (angle % 360)) / (360.0 / choices.size()));
        return choices.get(selectedIndex % choices.size());
    }

    private List<String> getRandomChoices(int n) {
        List<String> randomChoices = new ArrayList<>(choices);
        Collections.shuffle(randomChoices);
        return randomChoices.subList(0, n);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                RandomWheelApp frame = new RandomWheelApp();
                frame.setVisible(true);
            }
        });
    }
}

class WheelPanel extends JPanel {
    private List<String> choices;
    private int angle;

    public WheelPanel(List<String> choices) {
        this.choices = choices;
    }

    public void setChoices(List<String> choices) {
        this.choices = choices;
        repaint();
    }

    public void setAngle(int angle) {
        this.angle = angle;
        repaint();
    }

    @Override
protected void paintComponent(Graphics g) {
    super.paintComponent(g);
    if (choices == null || choices.isEmpty()) {
        return;
    }
    Graphics2D g2d = (Graphics2D) g;
    g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

    int width = getWidth();
    int height = getHeight();
    int minDim = Math.min(width, height);
    int radius = minDim / 2 - 10;
    int centerX = width / 2;
    int centerY = height / 2;

    g2d.translate(centerX, centerY);
    g2d.rotate(Math.toRadians(angle));

    int numChoices = choices.size();
    double anglePerChoice = 360.0 / numChoices;

    for (int i = 0; i < numChoices; i++) {
        g2d.setColor(Color.getHSBColor((float) i / numChoices, 0.8f, 0.8f));
        g2d.fillArc(-radius, -radius, 2 * radius, 2 * radius, (int) (-anglePerChoice / 2), (int) anglePerChoice);

        g2d.setColor(Color.BLACK);
        
        String choice = choices.get(i);
        int stringWidth = g2d.getFontMetrics().stringWidth(choice);
        g2d.rotate(Math.toRadians(anglePerChoice / 2));
        g2d.drawString(choice, -stringWidth / 2, -radius + 20);
        g2d.rotate(Math.toRadians(anglePerChoice / 2));
    }
    g2d.rotate(Math.toRadians(-anglePerChoice / 2 * numChoices));
    g2d.translate(-centerX, -centerY);
}

}

